#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${PYTHON:-python3}"
WHEEL="$(find dist -maxdepth 1 -name 'shipkit_ai-*.whl' -print -quit 2>/dev/null || true)"
if [[ -n "$WHEEL" ]]; then
  "$PYTHON" -m pip install --upgrade "$WHEEL"
else
  "$PYTHON" -m pip install .
fi
"$PYTHON" -m shipkit install codex
"$PYTHON" -m shipkit doctor
printf '\nShipKit installation finished. Restart Codex before testing a new chat.\n'

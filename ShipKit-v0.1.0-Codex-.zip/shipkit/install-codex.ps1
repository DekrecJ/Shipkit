$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    $wheel = Get-ChildItem -Path (Join-Path $PSScriptRoot "dist") -Filter "shipkit_ai-*.whl" -ErrorAction SilentlyContinue | Select-Object -First 1

    if (Get-Command py -ErrorAction SilentlyContinue) {
        if ($wheel) {
            py -3 -m pip install --upgrade $wheel.FullName
        } else {
            py -3 -m pip install .
        }
        py -3 -m shipkit install codex
        py -3 -m shipkit doctor
    }
    elseif (Get-Command python -ErrorAction SilentlyContinue) {
        if ($wheel) {
            python -m pip install --upgrade $wheel.FullName
        } else {
            python -m pip install .
        }
        python -m shipkit install codex
        python -m shipkit doctor
    }
    else {
        throw "Python 3.10+ was not found. Install Python, then run this script again."
    }

    Write-Host ""
    Write-Host "ShipKit installation finished. Restart Codex before testing a new chat." -ForegroundColor Green
}
finally {
    Pop-Location
}

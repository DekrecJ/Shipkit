# ShipKit

**Software Delivery Orchestrator for AI Coding Agents**

ShipKit adds a repeatable software-delivery workflow to AI coding agents such as **Codex** and, experimentally, **Claude Code**.

Instead of letting an agent jump directly from an idea to code, ShipKit guides the project through a structured lifecycle:

```text
Idea
  ↓
Discovery
  ↓
Requirements
  ↓
Architecture
  ↓
Implementation
  ↓
Testing
  ↓
Security Review
  ↓
Release
```

ShipKit is **not an AI model**. Codex or Claude remains the reasoning and coding engine. ShipKit provides the methodology, skills, project state, reusable rules, and deterministic checks that keep the agent working through a consistent engineering process.

---

## Why ShipKit?

AI coding agents are very good at producing code quickly, but a project can still fail because important engineering steps were skipped:

- unclear requirements;
- unnecessary architecture;
- missing authorization;
- secrets committed to the repository;
- no test strategy;
- no persistent record of project decisions;
- incomplete documentation;
- a project being declared "finished" without actually building or passing tests.

ShipKit is designed to reduce those problems by separating two responsibilities:

```text
Codex / Claude
    │
    │ reasoning + implementation
    ▼
ShipKit Skills
    │
    │ workflow + rules + project state
    ▼
Repository
    │
    │ real files + code + tests
    ▼
ShipKit CLI
    │
    │ deterministic verification
    ▼
READY / NOT_READY
```

The agent decides **how to build** the software. ShipKit makes sure the development process is structured and that release checks are based on the actual repository rather than only the model's opinion.

---

# Main Features

ShipKit v0.1.0 provides:

- **Codex integration** through persistent instructions and agent skills;
- **7 ShipKit skills** for project routing, analysis, planning, implementation, testing, security, and release;
- persistent project state stored in `.shipkit/`;
- support for multiple project categories;
- beginner, intermediate, and advanced project levels;
- reusable architecture blueprints and capability rules;
- automatic project lifecycle routing;
- project status tracking;
- deterministic build, lint, test, security, structure, and documentation checks;
- release scoring from `0–100`;
- machine-readable output with `shipkit check --json`;
- Windows, Linux, and macOS installation scripts;
- no required OpenAI or Anthropic API key;
- no ShipKit cloud account or external service required.

---

# Supported Project Types

ShipKit currently recognizes these project categories:

| Type | Identifier | Example |
|---|---|---|
| Web application | `web_app` | Expense tracker, dashboard, internal tool |
| SaaS | `saas` | CRM, inventory platform, multi-user business app |
| API | `api` | REST API, backend service |
| Automation | `automation` | n8n-style workflows, processing pipelines |
| AI application | `ai_app` | RAG app, document assistant, AI workflow |
| Mobile application | `mobile_app` | Flutter/React Native product |
| CLI tool | `cli_tool` | Developer utility, data-processing command |

ShipKit also supports three development levels:

- `beginner`
- `intermediate`
- `advanced`

The level is intended to change how work is divided and explained, not lower the expected quality of the final project.

---

# How ShipKit Works

## 1. You describe the project

Example:

```text
I want to build a SaaS for automotive repair shops where mechanics
update repair jobs and customers can track the status of their cars.
```

## 2. Codex activates ShipKit

When the installed `shipkit-router` skill determines that the request is a new or substantial software project, it starts or resumes the ShipKit lifecycle.

A new project should begin with:

```text
◆ ShipKit active
```

An existing ShipKit project should begin with:

```text
◆ ShipKit resumed
```

If automatic activation does not happen, you can explicitly invoke:

```text
$shipkit-router Build a SaaS for automotive repair shops...
```

## 3. ShipKit creates persistent project state

The repository receives a `.shipkit/` directory:

```text
.shipkit/
├── project.json
├── state.json
├── PROJECT.md
├── REQUIREMENTS.md
├── ARCHITECTURE.md
├── DATABASE.md
├── SECURITY.md
├── TESTING.md
└── TASKS.md
```

This is important because ShipKit does **not rely on chat history** to remember the project.

You can close Codex, open a new chat later, and the agent can read the files in `.shipkit/` to understand the current architecture, phase, requirements, and pending work.

## 4. Codex implements the project

Codex remains responsible for writing, modifying, testing, and debugging code.

ShipKit routes work through the appropriate skill according to the current phase.

## 5. ShipKit verifies the repository

Run:

```bash
shipkit check
```

ShipKit then evaluates the actual repository and produces a deterministic score and release status.

---

# Installation

## Requirements

### Required

- **Python 3.10 or newer**
- **Git**
- **Codex** installed and available from the terminal for the primary workflow

### Project-dependent / optional

- Node.js
- npm
- Docker
- other tools required by the project being built

ShipKit itself has **no third-party Python runtime dependencies** in v0.1.0.

You can verify your environment after installation with:

```bash
shipkit doctor
```

---

# Windows Installation

## Recommended method

### 1. Download ShipKit

Download or clone this repository, then open the ShipKit folder.

If using the packaged release, extract the ZIP first.

Expected files include:

```text
shipkit/
├── install-codex.ps1
├── dist/
│   └── shipkit_ai-0.1.0-py3-none-any.whl
├── shipkit/
├── skills/
├── blueprints/
└── README.md
```

### 2. Open PowerShell in the ShipKit folder

In File Explorer:

1. Open the extracted `shipkit` folder.
2. Right-click an empty area.
3. Choose **Open in Terminal** / **Open PowerShell here**.

### 3. Allow the local installation script for this session

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

This changes the execution policy **only for the current PowerShell process**.

### 4. Run the installer

```powershell
.\install-codex.ps1
```

The installer will:

1. detect `py` or `python`;
2. install the bundled ShipKit wheel when available;
3. install ShipKit's Codex integration;
4. copy ShipKit skills;
5. install the local blueprint/capability/template library;
6. add the managed ShipKit bootstrap block to Codex `AGENTS.md`;
7. run `shipkit doctor`.

A successful installation ends with a message similar to:

```text
ShipKit installation finished. Restart Codex before testing a new chat.
```

### 5. Restart Codex

Close the current Codex session and start a new one so it can discover the installed instructions and skills.

### 6. Verify ShipKit

Run:

```powershell
shipkit --version
```

Expected:

```text
ShipKit 0.1.0
```

Then:

```powershell
shipkit doctor
```

Example output:

```text
SHIPKIT DOCTOR 0.1.0
Python: 3.x.x ✓
✓ git
✓ codex
✓ node
✓ npm
○ docker
```

Docker is optional unless the project requires it.

---

# Linux / macOS Installation

## 1. Enter the ShipKit repository

```bash
cd shipkit
```

## 2. Make the installer executable

```bash
chmod +x install-codex.sh
```

## 3. Install

```bash
./install-codex.sh
```

The script installs the bundled wheel when present, configures Codex, and runs `shipkit doctor`.

## 4. Restart Codex

Start a new Codex session after installation.

## 5. Verify

```bash
shipkit --version
shipkit doctor
```

---

# Manual Installation

If you do not want to use the installation scripts:

```bash
python -m pip install .
python -m shipkit install codex
python -m shipkit doctor
```

On Windows, if `python` is not the correct launcher:

```powershell
py -3 -m pip install .
py -3 -m shipkit install codex
py -3 -m shipkit doctor
```

If the prebuilt wheel is available, it can also be installed directly:

```bash
python -m pip install dist/shipkit_ai-0.1.0-py3-none-any.whl
python -m shipkit install codex
```

---

# What the Codex Installer Changes

Running:

```bash
shipkit install codex
```

performs local changes only.

## 1. Installs skills

Default location:

```text
~/.agents/skills/
```

ShipKit creates directories such as:

```text
~/.agents/skills/
├── shipkit-router/
├── shipkit-project-analyzer/
├── shipkit-project-planner/
├── shipkit-implementation/
├── shipkit-testing-review/
├── shipkit-security-review/
└── shipkit-release-review/
```

You can override the skill directory using:

```text
SHIPKIT_SKILLS_HOME
```

## 2. Adds Codex bootstrap instructions

ShipKit adds a managed block to:

```text
$CODEX_HOME/AGENTS.md
```

If `CODEX_HOME` is not defined, ShipKit uses:

```text
~/.codex/AGENTS.md
```

ShipKit does **not intentionally replace unrelated instructions** in the file. It manages its own `SHIPKIT-GLOBAL` block.

## 3. Installs the ShipKit local library

Default location:

```text
~/.shipkit/library/
```

Containing:

```text
~/.shipkit/library/
├── blueprints/
├── capabilities/
└── templates/
```

---

# First Use

## Automatic activation test

Create or enter a new empty folder:

```bash
mkdir workshop-flow
cd workshop-flow
codex
```

Then tell Codex:

```text
Create a SaaS where mechanics update repair jobs and customers track their vehicles.
```

When ShipKit is detected and used correctly, Codex should start with:

```text
◆ ShipKit active
```

and initialize the repository with ShipKit metadata.

## Explicit activation test

If you want to guarantee activation during testing:

```text
$shipkit-router Create a SaaS where mechanics update repair jobs and customers track their vehicles.
```

You can also ask:

```text
Use $shipkit-router and report the current ShipKit status.
```

---

# Starting ShipKit Manually

You can initialize a repository without waiting for the agent:

```bash
shipkit init
```

Or define project information explicitly:

```bash
shipkit init \
  --name WorkshopFlow \
  --type saas \
  --level intermediate
```

Windows PowerShell equivalent:

```powershell
shipkit init --name WorkshopFlow --type saas --level intermediate
```

Available project types:

```text
unknown
web_app
saas
api
automation
ai_app
mobile_app
cli_tool
```

Available levels:

```text
beginner
intermediate
advanced
```

---

# ShipKit Lifecycle

ShipKit tracks seven phases:

```text
1. discovery
2. requirements
3. architecture
4. implementation
5. testing
6. security
7. release
```

## Discovery

Defines:

- problem;
- users;
- roles;
- platform;
- core capabilities;
- constraints;
- complexity.

## Requirements

Defines functional requirements and acceptance criteria.

## Architecture

Defines the simplest reasonable architecture for the detected requirements.

ShipKit skills are instructed to distinguish between:

- required complexity;
- recommended complexity;
- optional complexity;
- rejected/unnecessary complexity.

## Implementation

Codex implements tasks while ShipKit maintains project state.

## Testing

The testing review checks whether the project has appropriate evidence and test coverage for its declared capabilities.

## Security

The security review checks project-specific concerns such as secrets, authorization, multi-tenant isolation, and other relevant requirements.

## Release

The release phase combines documentation, state, test results, build status, and deterministic checks before the project is considered ready.

---

# Included Skills

## `shipkit-router`

Entry point for the ShipKit lifecycle.

Responsibilities:

- determines whether ShipKit applies;
- activates a new project;
- resumes an existing project;
- routes the agent to the correct phase skill.

## `shipkit-project-analyzer`

Analyzes the user's software idea and extracts structured project information.

Typical outputs include:

- project category;
- users and roles;
- capabilities;
- persistence requirements;
- security implications;
- complexity.

## `shipkit-project-planner`

Produces requirements, architecture, database/security considerations, test strategy, and task planning.

## `shipkit-implementation`

Guides the coding agent during implementation while keeping work aligned with ShipKit tasks and state.

## `shipkit-testing-review`

Reviews test strategy and evidence before release.

## `shipkit-security-review`

Reviews the project against declared security requirements.

## `shipkit-release-review`

Coordinates final release review and deterministic ShipKit checks.

---

# CLI Reference

## Version

```bash
shipkit --version
```

---

## Install Codex integration

```bash
shipkit install codex
```

Installs ShipKit skills, the local library, and Codex bootstrap instructions.

---

## Experimental Claude Code installation

```bash
shipkit install claude
```

Claude support is experimental in v0.1.0 and is less complete than the primary Codex workflow.

---

## Initialize a project

```bash
shipkit init
```

Optional arguments:

```bash
shipkit init --name MyProject --type saas --level intermediate
```

Force recreation of ShipKit metadata:

```bash
shipkit init --force
```

Use `--force` carefully because it can replace ShipKit project metadata.

---

## Project status

```bash
shipkit status
```

Example:

```text
SHIPKIT STATUS
Project: WorkshopFlow
Type: saas
Level: intermediate
Progress: ███████░░░░░░░░░░░░░ 43%
Current phase: implementation
Current task: WORKORDER-004

✓ discovery       completed
✓ requirements    completed
✓ architecture    completed
◐ implementation  in_progress
○ testing         pending
○ security        pending
○ release         pending
```

---

## Update a phase

```bash
shipkit phase implementation --status in_progress
```

Available phase states:

```text
pending
in_progress
completed
blocked
```

Example:

```bash
shipkit phase testing --status completed
```

---

## Update a task

```bash
shipkit task AUTH-001 --status in_progress
```

Complete it:

```bash
shipkit task AUTH-001 --status completed
```

Block it:

```bash
shipkit task AUTH-001 --status blocked
```

---

## Run release checks

```bash
shipkit check
```

Machine-readable result:

```bash
shipkit check --json
```

The command exits successfully only when the result is `READY`. A `NOT_READY` project returns a non-zero exit code, which makes the command useful in CI/CD workflows.

---

## Diagnose the local environment

```bash
shipkit doctor
```

Checks:

- Python;
- Git;
- Codex;
- Node.js;
- npm;
- Docker;
- Codex home;
- ShipKit skill directory.

Some tools are optional and only matter when the current project requires them.

---

# Deterministic Quality Checks

`shipkit check` does not ask the model whether the project is complete. It inspects and executes against the repository.

Current checks include:

## Structure

Verifies ShipKit/project structure and expected files.

## Build

Uses configured project build behavior when available.

## Lint / type checking

Runs configured lint/type checks when available.

## Tests

Runs configured test commands and uses the real exit status.

## Security

Current v0.1 checks include high-confidence repository checks such as:

- obvious secret patterns;
- environment-file handling;
- evidence of authorization testing when authorization is declared;
- evidence of tenant-isolation testing when multi-tenancy is declared.

These checks are intentionally conservative and do not replace a professional security audit.

## Documentation

Checks ShipKit documentation expected for the project lifecycle.

## State consistency

Checks that ShipKit phase/project metadata is internally consistent.

---

# Release Score

ShipKit generates a deterministic score from `0–100`.

Example:

```text
SHIPKIT CHECK
======================================================

STRUCTURE [10/10]
  ✓ ShipKit metadata
  ✓ repository structure

BUILD [20/20]
  ✓ build command

TESTS [18/25]
  ✗ authorization test evidence missing

SECURITY [20/25]
  ✓ environment handling
  ✓ obvious secret scan

DOCUMENTATION [10/10]
  ✓ architecture
  ✓ testing
  ✓ security

======================================================
Score: 86/100
Status: NOT_READY

Blockers:
  - authorization test evidence missing
```

The exact output depends on the project and configured checks.

---

# Project Persistence

One of ShipKit's core goals is to make the project independent from a specific chat session.

Example:

```text
project/
├── .shipkit/
│   ├── project.json
│   ├── state.json
│   ├── PROJECT.md
│   ├── REQUIREMENTS.md
│   ├── ARCHITECTURE.md
│   ├── DATABASE.md
│   ├── SECURITY.md
│   ├── TESTING.md
│   └── TASKS.md
├── AGENTS.md
└── ... application files
```

When you open a new Codex chat inside the same repository, ShipKit is designed to read the repository state instead of depending on the old conversation.

This means architectural decisions and development progress live with the code.

---

# Example Use Cases

## Beginner: Personal Expense Tracker

Prompt:

```text
Create a simple application where I can register and categorize my personal expenses.
```

A proportional ShipKit plan may determine that the MVP does **not** need:

- authentication;
- cloud database;
- Docker;
- microservices.

A simple React + TypeScript + local persistence architecture may be enough.

The goal is to prevent unnecessary complexity.

---

## Intermediate: Workshop SaaS

Prompt:

```text
Create a SaaS for automotive workshops. Mechanics update repair jobs,
customers track their vehicles, and administrators manage the workshop.
```

ShipKit may identify requirements such as:

- authentication;
- multiple roles;
- relational database;
- authorization;
- notifications;
- audit/history requirements;
- integration and E2E testing.

---

## AI Application: Document Assistant

Prompt:

```text
Create a platform where companies upload PDFs and ask questions about their documents.
```

ShipKit may detect:

- file storage;
- document processing;
- embeddings;
- vector retrieval;
- RAG;
- authentication;
- tenant isolation;
- AI-specific evaluation requirements.

The project still uses the normal ShipKit lifecycle rather than immediately jumping to implementation.

---

# Repository Structure

```text
shipkit/
│
├── shipkit/                 # Python CLI and deterministic checks
│   ├── checks/
│   ├── installer/
│   ├── state/
│   ├── cli.py
│   └── project_setup.py
│
├── skills/                  # Skills used by Codex/Claude
│   ├── shipkit-router/
│   ├── shipkit-project-analyzer/
│   ├── shipkit-project-planner/
│   ├── shipkit-implementation/
│   ├── shipkit-testing-review/
│   ├── shipkit-security-review/
│   └── shipkit-release-review/
│
├── blueprints/              # Base project-category rules
│   ├── web_app.json
│   ├── saas.json
│   ├── api.json
│   ├── automation.json
│   ├── ai_app.json
│   ├── mobile_app.json
│   └── cli_tool.json
│
├── capabilities/            # Reusable project capability rules
│   ├── auth.json
│   ├── database.json
│   ├── rbac.json
│   ├── multi_tenant.json
│   ├── storage.json
│   ├── notifications.json
│   ├── payments.json
│   ├── realtime.json
│   └── ai.json
│
├── templates/               # Project/state documentation templates
├── tests/                   # ShipKit's own automated tests
├── examples/
├── dist/                    # Prebuilt wheel
├── install-codex.ps1
├── install-codex.sh
├── pyproject.toml
└── README.md
```

---

# Troubleshooting

## `shipkit` command is not recognized

Try:

```bash
python -m shipkit --version
```

On Windows:

```powershell
py -3 -m shipkit --version
```

If that works, Python installed the package but the Python scripts directory is not available on your shell `PATH`.

You can still use:

```powershell
py -3 -m shipkit doctor
py -3 -m shipkit install codex
```

---

## Python is not found

ShipKit requires Python 3.10+.

Verify:

```bash
python --version
```

or on Windows:

```powershell
py -3 --version
```

After installing Python, reopen the terminal and run the ShipKit installer again.

---

## PowerShell blocks `install-codex.ps1`

Use a process-scoped policy:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

Then:

```powershell
.\install-codex.ps1
```

This applies only to the current PowerShell process.

---

## Codex does not automatically activate ShipKit

First verify installation:

```bash
shipkit doctor
```

Then explicitly invoke the router inside Codex:

```text
$shipkit-router Create a new SaaS for inventory management.
```

You can inspect the installed skill directory:

```text
~/.agents/skills/
```

and Codex bootstrap instructions:

```text
~/.codex/AGENTS.md
```

If `CODEX_HOME` is set, inspect that directory instead.

Automatic skill discovery ultimately depends on the installed Codex version/model correctly loading the available skill and instructions. Explicit `$shipkit-router` invocation is the recommended diagnostic fallback.

---

## Project says `No ShipKit project found`

Initialize the current repository:

```bash
shipkit init
```

Then:

```bash
shipkit status
```

---

## `shipkit check` returns `NOT_READY`

That is expected when required checks fail.

Read the blockers at the bottom of the output, fix the repository, then run:

```bash
shipkit check
```

again.

`NOT_READY` is a quality-gate result, not a ShipKit execution error.

---

# Uninstall

Remove the Codex integration:

```bash
shipkit uninstall codex
```

Then remove the Python package:

```bash
python -m pip uninstall shipkit-ai
```

Windows alternative:

```powershell
py -3 -m pip uninstall shipkit-ai
```

The Codex uninstall removes ShipKit skill directories, ShipKit's managed global instruction block, and its local ShipKit library.

It does not automatically delete `.shipkit/` directories from your existing project repositories.

---

# Development

Clone the repository and install in editable mode:

```bash
python -m pip install -e .
```

Run ShipKit's tests:

```bash
python -m unittest discover -s tests -v
```

Run environment diagnostics:

```bash
python -m shipkit doctor
```

ShipKit v0.1.0 was packaged after the included automated test suite passed **4/4 tests**. See [`TEST_REPORT.md`](TEST_REPORT.md) for the validation summary.

---

# Current Limitations

ShipKit v0.1.0 is an **alpha** release.

It does **not** currently:

- contain its own LLM;
- replace Codex or Claude Code;
- require or manage an OpenAI/Anthropic API key;
- run a ShipKit cloud backend;
- guarantee production readiness;
- replace penetration testing or a professional security audit;
- automatically understand free-form project descriptions inside the Python CLI itself;
- guarantee automatic skill activation on every Codex version/model;
- provide a web dashboard;
- provide team/project cloud synchronization.

Natural-language understanding is performed by the coding agent using ShipKit's installed skills.

The CLI handles deterministic installation, state management, status, and repository checks.

---

# Design Principle

ShipKit follows one central rule:

> **The model may reason about the project, but readiness must be verified against the actual repository.**

That separation is intentional:

```text
AI agent
  → interpretation
  → architecture
  → implementation

ShipKit CLI
  → state
  → tests
  → build
  → repository checks
  → release gate
```

---

# Roadmap

Potential next versions may include:

### v0.2

- improved Claude Code integration;
- additional project/capability blueprints;
- richer security checks;
- GitHub Actions generation;
- improved framework detection.

### v0.3

- GitHub integration;
- pull-request quality gates;
- CI result integration;
- project architecture change records.

### v0.4+

- optional visual dashboard;
- architecture visualization;
- team workflows;
- project history and delivery analytics.

---

# Contributing

Contributions are welcome.

See:

```text
CONTRIBUTING.md
```

Useful contribution areas include:

- new project blueprints;
- capability definitions;
- additional deterministic checks;
- skills for new coding agents;
- test fixtures;
- documentation improvements.

---

# License

ShipKit is released under the **MIT License**.

See [`LICENSE`](LICENSE).

---

# Quick Start Summary

### Windows

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install-codex.ps1
shipkit doctor
```

Restart Codex, open a project folder, and describe what you want to build.

### Linux/macOS

```bash
chmod +x install-codex.sh
./install-codex.sh
shipkit doctor
```

Then restart Codex.

### Test inside Codex

```text
$shipkit-router Create a SaaS for repair shops where mechanics update jobs and customers track their vehicles.
```

### Check the project

```bash
shipkit status
shipkit check
```

---

**ShipKit does not replace your coding agent. It gives your coding agent a software-delivery process.**
